import json
import os
import random
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, Request, Form, UploadFile, File, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from passlib.context import CryptContext
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from sqlalchemy import create_engine, String, Text, Integer, DateTime, Boolean, ForeignKey, select, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, Session, relationship

BASE = Path(__file__).resolve().parent
SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "elk")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "change-me")
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{BASE.parent / 'studybank.db'}")

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
serializer = URLSafeTimedSerializer(SECRET_KEY)

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20), default="user")
    active: Mapped[bool] = mapped_column(Boolean, default=True)

class Question(Base):
    __tablename__ = "questions"
    id: Mapped[int] = mapped_column(primary_key=True)
    type: Mapped[str] = mapped_column(String(20), default="mcq")
    subject: Mapped[str] = mapped_column(String(120), default="")
    topic: Mapped[str] = mapped_column(String(200), default="")
    difficulty: Mapped[int] = mapped_column(Integer, default=5)
    question: Mapped[str] = mapped_column(Text)
    choices_json: Mapped[str] = mapped_column(Text, default="[]")
    answer: Mapped[str] = mapped_column(Text, default="")
    explanation: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class ErrorItem(Base):
    __tablename__ = "errors"
    id: Mapped[int] = mapped_column(primary_key=True)
    question: Mapped[str] = mapped_column(Text)
    my_answer: Mapped[str] = mapped_column(Text, default="")
    correct_answer: Mapped[str] = mapped_column(Text, default="")
    reason: Mapped[str] = mapped_column(Text, default="")
    note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Note(Base):
    __tablename__ = "notes"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(200))
    body: Mapped[str] = mapped_column(Text)
    subject: Mapped[str] = mapped_column(String(120), default="")
    topic: Mapped[str] = mapped_column(String(200), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(engine)

def ensure_admin():
    with Session(engine) as db:
        admin = db.scalar(select(User).where(User.username == ADMIN_USERNAME))
        if not admin:
            db.add(User(username=ADMIN_USERNAME, password_hash=pwd.hash(ADMIN_PASSWORD), role="admin", active=True))
            db.commit()

ensure_admin()

app = FastAPI(title="Study Bank MVP")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")
templates = Jinja2Templates(directory=BASE / "templates")
templates.env.filters["fromjson"] = json.loads

def current_user(request: Request):
    token = request.cookies.get("session")
    if not token:
        return None
    try:
        data = serializer.loads(token, max_age=60 * 60 * 24 * 14)
    except (BadSignature, SignatureExpired):
        return None
    with Session(engine) as db:
        return db.get(User, int(data["uid"]))

def require_user(request: Request):
    user = current_user(request)
    if not user or not user.active:
        raise HTTPException(status_code=401)
    return user

def require_admin(request: Request):
    user = require_user(request)
    if user.role != "admin":
        raise HTTPException(status_code=403)
    return user

@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    user = current_user(request)
    if not user:
        return RedirectResponse("/login", 303)
    with Session(engine) as db:
        counts = {
            "questions": db.scalar(select(func.count()).select_from(Question)),
            "errors": db.scalar(select(func.count()).select_from(ErrorItem)),
            "notes": db.scalar(select(func.count()).select_from(Note)),
        }
    return templates.TemplateResponse("dashboard.html", {"request": request, "user": user, "counts": counts})

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    if current_user(request):
        return RedirectResponse("/", 303)
    return templates.TemplateResponse("login.html", {"request": request, "error": None})

@app.post("/login", response_class=HTMLResponse)
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    with Session(engine) as db:
        user = db.scalar(select(User).where(User.username == username))
        if not user or not user.active or not pwd.verify(password, user.password_hash):
            return templates.TemplateResponse("login.html", {"request": request, "error": "بيانات الدخول غير صحيحة."}, status_code=401)
        token = serializer.dumps({"uid": user.id})
    response = RedirectResponse("/", 303)
    response.set_cookie("session", token, httponly=True, samesite="lax", secure=False, max_age=60*60*24*14)
    return response

@app.post("/logout")
def logout():
    response = RedirectResponse("/login", 303)
    response.delete_cookie("session")
    return response

@app.get("/questions", response_class=HTMLResponse)
def questions(request: Request, q: str = "", subject: str = "", topic: str = "", type: str = ""):
    user = require_user(request)
    with Session(engine) as db:
        stmt = select(Question).order_by(Question.id.desc())
        if q:
            stmt = stmt.where(Question.question.ilike(f"%{q}%"))
        if subject:
            stmt = stmt.where(Question.subject == subject)
        if topic:
            stmt = stmt.where(Question.topic == topic)
        if type:
            stmt = stmt.where(Question.type == type)
        items = db.scalars(stmt.limit(500)).all()
    return templates.TemplateResponse("questions.html", {"request": request, "user": user, "items": items, "q": q})

@app.post("/questions")
def add_question(request: Request, type: str = Form("mcq"), subject: str = Form(""), topic: str = Form(""),
                 difficulty: int = Form(5), question: str = Form(...), choices: str = Form(""), answer: str = Form(""), explanation: str = Form("")):
    require_user(request)
    parsed = [x.strip() for x in choices.split("|") if x.strip()]
    with Session(engine) as db:
        db.add(Question(type=type, subject=subject, topic=topic, difficulty=max(1,min(10,difficulty)),
                        question=question, choices_json=json.dumps(parsed, ensure_ascii=False), answer=answer, explanation=explanation))
        db.commit()
    return RedirectResponse("/questions", 303)

@app.post("/questions/{qid}/delete")
def delete_question(request: Request, qid: int):
    require_user(request)
    with Session(engine) as db:
        item = db.get(Question, qid)
        if item:
            db.delete(item); db.commit()
    return RedirectResponse("/questions", 303)

@app.get("/errors", response_class=HTMLResponse)
def errors(request: Request):
    user = require_user(request)
    with Session(engine) as db:
        items = db.scalars(select(ErrorItem).order_by(ErrorItem.id.desc())).all()
    return templates.TemplateResponse("errors.html", {"request": request, "user": user, "items": items})

@app.post("/errors")
def add_error(request: Request, question: str = Form(...), my_answer: str = Form(""),
              correct_answer: str = Form(""), reason: str = Form(""), note: str = Form("")):
    require_user(request)
    with Session(engine) as db:
        db.add(ErrorItem(question=question, my_answer=my_answer, correct_answer=correct_answer, reason=reason, note=note))
        db.commit()
    return RedirectResponse("/errors", 303)

@app.get("/notes", response_class=HTMLResponse)
def notes(request: Request):
    user = require_user(request)
    with Session(engine) as db:
        items = db.scalars(select(Note).order_by(Note.id.desc())).all()
    return templates.TemplateResponse("notes.html", {"request": request, "user": user, "items": items})

@app.post("/notes")
def add_note(request: Request, title: str = Form(...), body: str = Form(...), subject: str = Form(""), topic: str = Form("")):
    require_user(request)
    with Session(engine) as db:
        db.add(Note(title=title, body=body, subject=subject, topic=topic))
        db.commit()
    return RedirectResponse("/notes", 303)

@app.get("/exam", response_class=HTMLResponse)
def exam_page(request: Request):
    user = require_user(request)
    return templates.TemplateResponse("exam.html", {"request": request, "user": user, "exam": None, "result": None})

@app.post("/exam", response_class=HTMLResponse)
def generate_exam(request: Request, count: int = Form(10), subject: str = Form(""), type: str = Form("")):
    user = require_user(request)
    with Session(engine) as db:
        stmt = select(Question)
        if subject: stmt = stmt.where(Question.subject == subject)
        if type: stmt = stmt.where(Question.type == type)
        pool = list(db.scalars(stmt).all())
    random.shuffle(pool)
    exam = pool[:max(1,min(100,count))]
    return templates.TemplateResponse("exam.html", {"request": request, "user": user, "exam": exam, "result": None})

@app.post("/exam/grade", response_class=HTMLResponse)
async def grade_exam(request: Request):
    user = require_user(request)
    form = await request.form()
    ids = [int(x) for x in form.getlist("qid")]
    score = 0
    total = len(ids)
    with Session(engine) as db:
        for qid in ids:
            q = db.get(Question, qid)
            if q and q.type in ("mcq", "true_false"):
                if form.get(f"answer_{qid}", "").strip().lower() == q.answer.strip().lower():
                    score += 1
        exam = [db.get(Question, qid) for qid in ids]
    return templates.TemplateResponse("exam.html", {"request": request, "user": user, "exam": exam, "result": {"score": score, "total": total}})

@app.post("/import")
async def import_json(request: Request, file: UploadFile = File(...), kind: str = Form("questions")):
    require_user(request)
    raw = await file.read()
    data = json.loads(raw.decode("utf-8"))
    if not isinstance(data, list):
        raise HTTPException(400, "JSON must be an array")
    with Session(engine) as db:
        if kind == "questions":
            for x in data:
                db.add(Question(type=x.get("type","mcq"), subject=x.get("subject",""), topic=x.get("topic",""),
                    difficulty=int(x.get("difficulty",5)), question=x.get("question",""),
                    choices_json=json.dumps(x.get("choices",[]), ensure_ascii=False),
                    answer=x.get("answer",""), explanation=x.get("explanation","")))
        elif kind == "errors":
            for x in data:
                db.add(ErrorItem(question=x.get("question",""), my_answer=x.get("my_answer",""),
                    correct_answer=x.get("correct_answer",""), reason=x.get("reason",""), note=x.get("note","")))
        elif kind == "notes":
            for x in data:
                db.add(Note(title=x.get("title",""), body=x.get("body",""), subject=x.get("subject",""), topic=x.get("topic","")))
        else:
            raise HTTPException(400, "Unknown import kind")
        db.commit()
    return RedirectResponse("/", 303)

@app.get("/export")
def export_all(request: Request):
    require_user(request)
    with Session(engine) as db:
        qs = db.scalars(select(Question)).all()
        es = db.scalars(select(ErrorItem)).all()
        ns = db.scalars(select(Note)).all()
    payload = {
        "questions": [{"type":q.type,"subject":q.subject,"topic":q.topic,"difficulty":q.difficulty,"question":q.question,
                       "choices":json.loads(q.choices_json),"answer":q.answer,"explanation":q.explanation} for q in qs],
        "errors": [{"question":e.question,"my_answer":e.my_answer,"correct_answer":e.correct_answer,"reason":e.reason,"note":e.note} for e in es],
        "notes": [{"title":n.title,"body":n.body,"subject":n.subject,"topic":n.topic} for n in ns]
    }
    return JSONResponse(payload, headers={"Content-Disposition": "attachment; filename=studybank-backup.json"})

@app.get("/admin/users", response_class=HTMLResponse)
def users_page(request: Request):
    admin = require_admin(request)
    with Session(engine) as db:
        users = db.scalars(select(User).order_by(User.id)).all()
    return templates.TemplateResponse("users.html", {"request": request, "user": admin, "users": users})

@app.post("/admin/users")
def add_user(request: Request, username: str = Form(...), password: str = Form(...), role: str = Form("user")):
    require_admin(request)
    with Session(engine) as db:
        if db.scalar(select(User).where(User.username == username)):
            raise HTTPException(400, "Username already exists")
        db.add(User(username=username.strip(), password_hash=pwd.hash(password), role="admin" if role=="admin" else "user", active=True))
        db.commit()
    return RedirectResponse("/admin/users", 303)

@app.post("/admin/users/{uid}/toggle")
def toggle_user(request: Request, uid: int):
    require_admin(request)
    with Session(engine) as db:
        u = db.get(User, uid)
        if u and u.username != ADMIN_USERNAME:
            u.active = not u.active
            db.commit()
    return RedirectResponse("/admin/users", 303)

@app.post("/admin/users/{uid}/delete")
def delete_user(request: Request, uid: int):
    require_admin(request)
    with Session(engine) as db:
        u = db.get(User, uid)
        if u and u.username != ADMIN_USERNAME:
            db.delete(u); db.commit()
    return RedirectResponse("/admin/users", 303)
